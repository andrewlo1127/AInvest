-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2024-08-21 00:31:02
-- 伺服器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `專題`
--

-- --------------------------------------------------------

--
-- 資料表結構 `code`
--

CREATE TABLE `code` (
  `code_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `strategy` text NOT NULL COMMENT '策略名稱',
  `public` tinyint(1) NOT NULL COMMENT '0不公開/1公開',
  `description` text NOT NULL COMMENT '策略描述',
  `tempt_code` longtext NOT NULL,
  `file_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `code`
--

INSERT INTO `code` (`code_id`, `member_id`, `strategy`, `public`, `description`, `tempt_code`, `file_name`) VALUES
(1, 4, 'KDCross', 1, '', '', ''),
(3, 4, 'KDCross2', 1, 'agasdasd', 'print(\\\"Hello\\\")', ''),
(13, 5, 'newKD', 0, '此策略側重於匹配教師模型與學生模型之間的中間層特徵表示。除了使用傳統的輸出層知識蒸餾之外，還強調了學生模型學習到與教師模型相似的中間特徵表達。這種方法有助於學生模型更好地模仿教師模型的內部表示，提高其表現。', '# 模擬數據生成\nnp.random.seed(42)\nfeature_similarity = np.random.normal(0.6, 0.05, size=len(dates))  # 模擬特徵相似度\n\n# 建立DataFrame\ndf_feature_matching = pd.DataFrame({\n    \'Date\': dates,\n    \'Price\': price,\n    \'Feature_Similarity\': feature_similarity\n})\n\n# 計算進出場點\ndf_feature_matching[\'Signal\'] = np.where(df_feature_matching[\'Feature_Similarity\'] > 0.6, 1, -1)\ndf_feature_matching[\'Position\'] = df_feature_matching[\'Signal\'].shift()\ndf_feature_matching[\'Profit\'] = df_feature_matching[\'Position\'] * (df_feature_matching[\'Price\'].diff())\n\n# 繪製趨勢圖\nplt.figure(figsize=(14, 8))\nplt.plot(df_feature_matching[\'Date\'], df_feature_matching[\'Price\'], label=\'Price\')\nplt.scatter(df_feature_matching[\'Date\'], df_feature_matching[\'Price\'], c=df_feature_matching[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'Feature Matching KD Strategy - Price Trend and Entry/Exit Points\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Price\')\nplt.legend()\nplt.show()\n\n# 繪製累積獲利圖\ndf_feature_matching[\'Cumulative_Profit\'] = df_feature_matching[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_feature_matching[\'Date\'], df_feature_matching[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'Feature Matching KD Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()\n', ''),
(33, 5, 'newKD', 1, '此策略側重於匹配教師模型與學生模型之間的中間層特徵表示。除了使用傳統的輸出層知識蒸餾之外，還強調了學生模型學習到與教師模型相似的中間特徵表達。這種方法有助於學生模型更好地模仿教師模型的內部表示，提高其表現。', '# 模擬數據生成\nnp.random.seed(42)\nfeature_similarity = np.random.normal(0.6, 0.05, size=len(dates))  # 模擬特徵相似度\n\n# 建立DataFrame\ndf_feature_matching = pd.DataFrame({\n    \'Date\': dates,\n    \'Price\': price,\n    \'Feature_Similarity\': feature_similarity\n})\n\n# 計算進出場點\ndf_feature_matching[\'Signal\'] = np.where(df_feature_matching[\'Feature_Similarity\'] > 0.6, 1, -1)\ndf_feature_matching[\'Position\'] = df_feature_matching[\'Signal\'].shift()\ndf_feature_matching[\'Profit\'] = df_feature_matching[\'Position\'] * (df_feature_matching[\'Price\'].diff())\n\n# 繪製趨勢圖\nplt.figure(figsize=(14, 8))\nplt.plot(df_feature_matching[\'Date\'], df_feature_matching[\'Price\'], label=\'Price\')\nplt.scatter(df_feature_matching[\'Date\'], df_feature_matching[\'Price\'], c=df_feature_matching[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'Feature Matching KD Strategy - Price Trend and Entry/Exit Points\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Price\')\nplt.legend()\nplt.show()\n\n# 繪製累積獲利圖\ndf_feature_matching[\'Cumulative_Profit\'] = df_feature_matching[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_feature_matching[\'Date\'], df_feature_matching[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'Feature Matching KD Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()\n', ''),
(34, 5, 'oldKD', 1, '經典的KD策略，利用教師模型的soft targets進行知識傳遞。具體來說，教師模型在輸出時，不僅僅給出單一的最可能標籤，而是提供一個概率分布。學生模型在訓練時，學習這個概率分布，而不是單純的硬標籤（hard labels）。這樣可以讓學生模型學到更多的類間相似度信息，提升其泛化能力。', 'import pandas as pd\nimport numpy as np\nimport matplotlib.pyplot as plt\n\n# 模擬數據生成\nnp.random.seed(42)\ndates = pd.date_range(\'2023-01-01\', periods=100)\nprice = np.random.normal(100, 2, size=len(dates)).cumsum()  # 模擬價格走勢\nsoft_targets = np.random.normal(0.5, 0.1, size=len(dates))  # 模擬Soft Targets\n\n# 建立DataFrame\ndf_soft_targets = pd.DataFrame({\n    \'Date\': dates,\n    \'Price\': price,\n    \'Soft_Targets\': soft_targets\n})\n\n# 計算進出場點\ndf_soft_targets[\'Signal\'] = np.where(df_soft_targets[\'Soft_Targets\'] > 0.5, 1, -1)\ndf_soft_targets[\'Position\'] = df_soft_targets[\'Signal\'].shift()\ndf_soft_targets[\'Profit\'] = df_soft_targets[\'Position\'] * (df_soft_targets[\'Price\'].diff())\n\n# 繪製趨勢圖\nplt.figure(figsize=(14, 8))\nplt.plot(df_soft_targets[\'Date\'], df_soft_targets[\'Price\'], label=\'Price\')\nplt.scatter(df_soft_targets[\'Date\'], df_soft_targets[\'Price\'], c=df_soft_targets[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'Soft Targets KD Strategy - Price Trend and Entry/Exit Points\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Price\')\nplt.legend()\nplt.show()\n\n# 繪製累積獲利圖\ndf_soft_targets[\'Cumulative_Profit\'] = df_soft_targets[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_soft_targets[\'Date\'], df_soft_targets[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'Soft Targets KD Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()', ''),
(35, 5, 'oldKD', 0, '經典的KD策略，利用教師模型的soft targets進行知識傳遞。具體來說，教師模型在輸出時，不僅僅給出單一的最可能標籤，而是提供一個概率分布。學生模型在訓練時，學習這個概率分布，而不是單純的硬標籤（hard labels）。這樣可以讓學生模型學到更多的類間相似度信息，提升其泛化能力。', 'import pandas as pd\nimport numpy as np\nimport matplotlib.pyplot as plt\n\n# 模擬數據生成\nnp.random.seed(42)\ndates = pd.date_range(\'2023-01-01\', periods=100)\nprice = np.random.normal(100, 2, size=len(dates)).cumsum()  # 模擬價格走勢\nsoft_targets = np.random.normal(0.5, 0.1, size=len(dates))  # 模擬Soft Targets\n\n# 建立DataFrame\ndf_soft_targets = pd.DataFrame({\n    \'Date\': dates,\n    \'Price\': price,\n    \'Soft_Targets\': soft_targets\n})\n\n# 計算進出場點\ndf_soft_targets[\'Signal\'] = np.where(df_soft_targets[\'Soft_Targets\'] > 0.5, 1, -1)\ndf_soft_targets[\'Position\'] = df_soft_targets[\'Signal\'].shift()\ndf_soft_targets[\'Profit\'] = df_soft_targets[\'Position\'] * (df_soft_targets[\'Price\'].diff())\n\n# 繪製趨勢圖\nplt.figure(figsize=(14, 8))\nplt.plot(df_soft_targets[\'Date\'], df_soft_targets[\'Price\'], label=\'Price\')\nplt.scatter(df_soft_targets[\'Date\'], df_soft_targets[\'Price\'], c=df_soft_targets[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'Soft Targets KD Strategy - Price Trend and Entry/Exit Points\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Price\')\nplt.legend()\nplt.show()\n\n# 繪製累積獲利圖\ndf_soft_targets[\'Cumulative_Profit\'] = df_soft_targets[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_soft_targets[\'Date\'], df_soft_targets[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'Soft Targets KD Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()', ''),
(36, 6, 'RSI超買超賣策略', 0, '此策略使用相對強弱指數（RSI）來判斷市場的超買和超賣狀況。當RSI低於30時，市場進入超賣區，進行買入；當RSI高於70時，市場進入超買區，進行賣出。', 'import pandas as pd\nimport numpy as np\nimport matplotlib.pyplot as plt\n\n# 模擬數據生成\nnp.random.seed(42)\ndates = pd.date_range(\'2023-01-01\', periods=100)\nprice = np.random.normal(100, 2, size=len(dates)).cumsum()\n\n# 計算RSI\ndef calculate_rsi(prices, window=14):\n    delta = prices.diff(1)\n    gain = delta.where(delta > 0, 0)\n    loss = -delta.where(delta < 0, 0)\n    avg_gain = gain.rolling(window=window).mean()\n    avg_loss = loss.rolling(window=window).mean()\n    rs = avg_gain / avg_loss\n    rsi = 100 - (100 / (1 + rs))\n    return rsi\n\ndf_rsi = pd.DataFrame({\'Date\': dates, \'Price\': price})\ndf_rsi[\'RSI\'] = calculate_rsi(df_rsi[\'Price\'])\n\n# 計算進出場信號\ndf_rsi[\'Signal\'] = 0\ndf_rsi.loc[df_rsi[\'RSI\'] < 30, \'Signal\'] = 1\ndf_rsi.loc[df_rsi[\'RSI\'] > 70, \'Signal\'] = -1\ndf_rsi[\'Position\'] = df_rsi[\'Signal\'].shift()\ndf_rsi[\'Profit\'] = df_rsi[\'Position\'] * df_rsi[\'Price\'].diff()\n\n# 繪製價格和RSI\nplt.figure(figsize=(14, 8))\nplt.subplot(2, 1, 1)\nplt.plot(df_rsi[\'Date\'], df_rsi[\'Price\'], label=\'Price\')\nplt.scatter(df_rsi[\'Date\'], df_rsi[\'Price\'], c=df_rsi[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'RSI Strategy - Price and Entry/Exit Points\')\nplt.legend()\n\nplt.subplot(2, 1, 2)\nplt.plot(df_rsi[\'Date\'], df_rsi[\'RSI\'], label=\'RSI\')\nplt.axhline(70, color=\'r\', linestyle=\'--\')\nplt.axhline(30, color=\'g\', linestyle=\'--\')\nplt.title(\'RSI Indicator\')\nplt.legend()\nplt.tight_layout()\nplt.show()\n\n# 繪製累積獲利圖\ndf_rsi[\'Cumulative_Profit\'] = df_rsi[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_rsi[\'Date\'], df_rsi[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'RSI Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()\n', ''),
(39, 6, 'MACD背離策略', 0, '我想利用MACD來判斷市場趨勢的變化。當價格創新低，而MACD不再創新低時，形成背離，進行買入。當價格創新高，而MACD指標不再創新高時，則賣出。', 'import pandas as pd \nimport numpy as np \nimport matplotlib.pyplot as plt\n\n# 計算MACD\ndef calculate_macd(prices, short_window=12, long_window=26, signal_window=9):\n    exp1 = prices.ewm(span=short_window, adjust=False).mean()\n    exp2 = prices.ewm(span=long_window, adjust=False).mean()\n    macd = exp1 - exp2\n    signal = macd.ewm(span=signal_window, adjust=False).mean()\n    return macd, signal\n\ndf_macd = pd.DataFrame({\'Date\': dates, \'Price\': price})\ndf_macd[\'MACD\'], df_macd[\'Signal_Line\'] = calculate_macd(df_macd[\'Price\'])\n\n# 計算背離和進出場信號\ndf_macd[\'Signal\'] = 0\ndf_macd.loc[(df_macd[\'Price\'] < df_macd[\'Price\'].shift(1)) & (df_macd[\'MACD\'] > df_macd[\'MACD\'].shift(1)), \'Signal\'] = 1\ndf_macd.loc[(df_macd[\'Price\'] > df_macd[\'Price\'].shift(1)) & (df_macd[\'MACD\'] < df_macd[\'MACD\'].shift(1)), \'Signal\'] = -1\ndf_macd[\'Position\'] = df_macd[\'Signal\'].shift()\ndf_macd[\'Profit\'] = df_macd[\'Position\'] * df_macd[\'Price\'].diff()\n\n# 繪製價格和MACD\nplt.figure(figsize=(14, 8))\nplt.subplot(2, 1, 1)\nplt.plot(df_macd[\'Date\'], df_macd[\'Price\'], label=\'Price\')\nplt.scatter(df_macd[\'Date\'], df_macd[\'Price\'], c=df_macd[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'MACD Divergence Strategy - Price and Entry/Exit Points\')\nplt.legend()\n\nplt.subplot(2, 1, 2)\nplt.plot(df_macd[\'Date\'], df_macd[\'MACD\'], label=\'MACD\')\nplt.plot(df_macd[\'Date\'], df_macd[\'Signal_Line\'], label=\'Signal Line\', linestyle=\'--\')\nplt.title(\'MACD Indicator\')\nplt.legend()\nplt.tight_layout()\nplt.show()\n\n# 繪製累積獲利圖\ndf_macd[\'Cumulative_Profit\'] = df_macd[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_macd[\'Date\'], df_macd[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'MACD Divergence Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()\n', ''),
(40, 6, '海龜交易', 0, '我的策略是根據海龜交易法則，使用突破法來決定買賣點。當價格突破過去20天的最高點時，進行買入；當價格跌破過去20天的最低點時，我會進行賣出。', 'import pandas as p\nimport numpy as np\nimport matplotlib.pyplot as plt\n\n# 計算最高價和最低價\ndf_turtle = pd.DataFrame({\n    \'Date\': dates,\n    \'Price\': price\n})\ndf_turtle[\'20D_High\'] = df_turtle[\'Price\'].rolling(window=20).max()\ndf_turtle[\'20D_Low\'] = df_turtle[\'Price\'].rolling(window=20).min()\n\n# 計算信號\ndf_turtle[\'Signal\'] = np.where(df_turtle[\'Price\'] > df_turtle[\'20D_High\'].shift(), 1,\n                               np.where(df_turtle[\'Price\'] < df_turtle[\'20D_Low\'].shift(), -1, 0))\ndf_turtle[\'Position\'] = df_turtle[\'Signal\'].shift()\ndf_turtle[\'Profit\'] = df_turtle[\'Position\'] * (df_turtle[\'Price\'].diff())\n\n# 繪製趨勢圖和信號\nplt.figure(figsize=(14, 8))\nplt.plot(df_turtle[\'Date\'], df_turtle[\'Price\'], label=\'Price\')\nplt.plot(df_turtle[\'Date\'], df_turtle[\'20D_High\'], label=\'20-Day High\', linestyle=\'--\')\nplt.plot(df_turtle[\'Date\'], df_turtle[\'20D_Low\'], label=\'20-Day Low\', linestyle=\'--\')\nplt.scatter(df_turtle[\'Date\'], df_turtle[\'Price\'], c=df_turtle[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'Turtle Trading Strategy - Price Trend and Entry/Exit Points\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Price\')\nplt.legend()\nplt.show()\n\n# 繪製累積獲利圖\ndf_turtle[\'Cumulative_Profit\'] = df_turtle[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_turtle[\'Date\'], df_turtle[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'Turtle Trading Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()\n', ''),
(49, 6, '黃金分割回撤', 0, '基於黃金分割回撤線來找到潛在的支撐。當價格回撤至0.618的黃金分割線並出現反彈跡象時，進行買入；當價格回升至0.618的黃金分割線並出現轉弱跡象時，進行賣出。', '# 模擬數據生成\nhighs = price * (1 + np.random.normal(0.05, 0.02, size=len(price)))\nlows = price * (1 - np.random.normal(0.05, 0.02, size=len(price)))\n\n# 計算黃金分割回撤\ndf_fib = pd.DataFrame({\n    \'Date\': dates,\n    \'Price\': price,\n    \'High\': highs,\n    \'Low\': lows\n})\n\ndf_fib[\'Fib_0.618\'] = df_fib[\'Low\'] + 0.618 * (df_fib[\'High\'] - df_fib[\'Low\'])\n\n# 計算信號\ndf_fib[\'Signal\'] = np.where((df_fib[\'Price\'] > df_fib[\'Fib_0.618\']) & (df_fib[\'Price\'].shift() < df_fib[\'Fib_0.618\']), 1,\n                            np.where((df_fib[\'Price\'] < df_fib[\'Fib_0.618\']) & (df_fib[\'Price\'].shift() > df_fib[\'Fib_0.618\']), -1, 0))\ndf_fib[\'Position\'] = df_fib[\'Signal\'].shift()\ndf_fib[\'Profit\'] = df_fib[\'Position\'] * (df_fib[\'Price\'].diff())\n\n# 繪製趨勢圖和信號\nplt.figure(figsize=(14, 8))\nplt.plot(df_fib[\'Date\'], df_fib[\'Price\'], label=\'Price\')\nplt.plot(df_fib[\'Date\'], df_fib[\'Fib_0.618\'], label=\'Fib 0.618 Level\', linestyle=\'--\')\nplt.scatter(df_fib[\'Date\'], df_fib[\'Price\'], c=df_fib[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'Fibonacci Retracement Strategy - Price Trend and Entry/Exit Points\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Price\')\nplt.legend()\nplt.show()\n\n# 繪製累積獲利圖\ndf_fib[\'Cumulative_Profit\'] = df_fib[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_fib[\'Date\'], df_fib[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'Fibonacci Retracement Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()\n', ''),
(56, 6, 'RSI超買超賣策略', 1, '此策略使用相對強弱指數（RSI）來判斷市場的超買和超賣狀況。當RSI低於30時，市場進入超賣區，進行買入；當RSI高於70時，市場進入超買區，進行賣出。', 'import pandas as pd\nimport numpy as np\nimport matplotlib.pyplot as plt\n\n# 模擬數據生成\nnp.random.seed(42)\ndates = pd.date_range(\'2023-01-01\', periods=100)\nprice = np.random.normal(100, 2, size=len(dates)).cumsum()\n\n# 計算RSI\ndef calculate_rsi(prices, window=14):\n    delta = prices.diff(1)\n    gain = delta.where(delta > 0, 0)\n    loss = -delta.where(delta < 0, 0)\n    avg_gain = gain.rolling(window=window).mean()\n    avg_loss = loss.rolling(window=window).mean()\n    rs = avg_gain / avg_loss\n    rsi = 100 - (100 / (1 + rs))\n    return rsi\n\ndf_rsi = pd.DataFrame({\'Date\': dates, \'Price\': price})\ndf_rsi[\'RSI\'] = calculate_rsi(df_rsi[\'Price\'])\n\n# 計算進出場信號\ndf_rsi[\'Signal\'] = 0\ndf_rsi.loc[df_rsi[\'RSI\'] < 30, \'Signal\'] = 1\ndf_rsi.loc[df_rsi[\'RSI\'] > 70, \'Signal\'] = -1\ndf_rsi[\'Position\'] = df_rsi[\'Signal\'].shift()\ndf_rsi[\'Profit\'] = df_rsi[\'Position\'] * df_rsi[\'Price\'].diff()\n\n# 繪製價格和RSI\nplt.figure(figsize=(14, 8))\nplt.subplot(2, 1, 1)\nplt.plot(df_rsi[\'Date\'], df_rsi[\'Price\'], label=\'Price\')\nplt.scatter(df_rsi[\'Date\'], df_rsi[\'Price\'], c=df_rsi[\'Signal\'], cmap=\'coolwarm\', label=\'Buy/Sell Signal\')\nplt.title(\'RSI Strategy - Price and Entry/Exit Points\')\nplt.legend()\n\nplt.subplot(2, 1, 2)\nplt.plot(df_rsi[\'Date\'], df_rsi[\'RSI\'], label=\'RSI\')\nplt.axhline(70, color=\'r\', linestyle=\'--\')\nplt.axhline(30, color=\'g\', linestyle=\'--\')\nplt.title(\'RSI Indicator\')\nplt.legend()\nplt.tight_layout()\nplt.show()\n\n# 繪製累積獲利圖\ndf_rsi[\'Cumulative_Profit\'] = df_rsi[\'Profit\'].cumsum()\nplt.figure(figsize=(14, 8))\nplt.plot(df_rsi[\'Date\'], df_rsi[\'Cumulative_Profit\'], label=\'Cumulative Profit\')\nplt.title(\'RSI Strategy - Cumulative Profit\')\nplt.xlabel(\'Date\')\nplt.ylabel(\'Cumulative Profit\')\nplt.legend()\nplt.show()\n', '');

-- --------------------------------------------------------

--
-- 資料表結構 `members`
--

CREATE TABLE `members` (
  `m_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `userbot_api` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `members`
--

INSERT INTO `members` (`m_id`, `name`, `email`, `password`, `userbot_api`) VALUES
(3, '然', 'a0976096595@gmail.com', '', ''),
(4, 'peko', 'qwe', '1', ''),
(5, 'zan', 'zan123@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', ''),
(6, 'qaz', 's110213049@mail1.ncnu.edu.tw', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '');

-- --------------------------------------------------------

--
-- 資料表結構 `target`
--

CREATE TABLE `target` (
  `t_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `target_id` text NOT NULL COMMENT '標的代號'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `target`
--

INSERT INTO `target` (`t_id`, `member_id`, `target_id`) VALUES
(1, 5, '0050'),
(2, 5, '2330');

-- --------------------------------------------------------

--
-- 資料表結構 `test_body`
--

CREATE TABLE `test_body` (
  `tb_id` int(11) NOT NULL,
  `th_id` int(11) NOT NULL COMMENT 'test_head',
  `enter_date` int(11) NOT NULL COMMENT '進場日期',
  `exit_date` int(11) NOT NULL COMMENT '出場日期',
  `enter_price` int(11) NOT NULL COMMENT '進場價格',
  `exit_price` int(11) NOT NULL COMMENT '出場價格',
  `size` tinyint(1) NOT NULL COMMENT '張數',
  `profit` int(11) NOT NULL COMMENT '獲利',
  `profit_margin` float NOT NULL COMMENT '獲利率'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `test_body`
--

INSERT INTO `test_body` (`tb_id`, `th_id`, `enter_date`, `exit_date`, `enter_price`, `exit_price`, `size`, `profit`, `profit_margin`) VALUES
(1, 1, 2014, 2014, 26, 24, 127, -716, -0.0716694),
(2, 1, 2015, 2015, 24, 22, 127, -749, -0.0807857),
(3, 1, 2016, 2016, 21, 22, 127, 522, 0.0611264),
(4, 1, 2018, 2018, 26, 27, 127, 426, 0.047226),
(5, 1, 2018, 2019, 24, 24, 127, 102, 0.0108095),
(6, 1, 2019, 2019, 25, 27, 127, 406, 0.0424209),
(7, 1, 2020, 2020, 23, 26, 127, 1653, 0.165584),
(8, 1, 2022, 2022, 31, 28, 127, -902, -0.0774699),
(9, 1, 2022, 2022, 27, 25, 127, -481, -0.0448159),
(10, 1, 2023, 2023, 33, 35, 127, 443, 0.0433133),
(11, 2, 2014, 2014, 26, 24, 127, -716, -0.0716694),
(12, 2, 2015, 2015, 24, 22, 127, -749, -0.0807857),
(13, 2, 2016, 2016, 21, 22, 127, 522, 0.0611264),
(14, 2, 2018, 2018, 26, 27, 127, 426, 0.047226),
(15, 2, 2018, 2019, 24, 24, 127, 102, 0.0108095),
(16, 2, 2019, 2019, 25, 27, 127, 406, 0.0424209),
(17, 2, 2020, 2020, 23, 26, 127, 1653, 0.165584),
(18, 2, 2022, 2022, 31, 28, 127, -902, -0.0774699),
(19, 2, 2022, 2022, 27, 25, 127, -481, -0.0448159),
(20, 2, 2023, 2023, 33, 35, 127, 443, 0.0433133),
(21, 3, 2014, 2014, 26, 24, 127, -716, -0.0716694),
(22, 3, 2015, 2015, 24, 22, 127, -749, -0.0807857),
(23, 3, 2016, 2016, 21, 22, 127, 522, 0.0611264),
(24, 3, 2018, 2018, 26, 27, 127, 426, 0.047226),
(25, 3, 2018, 2019, 24, 24, 127, 102, 0.0108095),
(26, 3, 2019, 2019, 25, 27, 127, 406, 0.0424209),
(27, 3, 2020, 2020, 23, 26, 127, 1653, 0.165584),
(28, 3, 2022, 2022, 31, 28, 127, -902, -0.0774699),
(29, 3, 2022, 2022, 27, 25, 127, -481, -0.0448159),
(30, 3, 2023, 2023, 33, 35, 127, 443, 0.0433133);

-- --------------------------------------------------------

--
-- 資料表結構 `test_head`
--

CREATE TABLE `test_head` (
  `th_id` int(11) NOT NULL,
  `code_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `target_name` varchar(10) NOT NULL,
  `times` int(11) NOT NULL COMMENT '次數',
  `sucess_p` float NOT NULL COMMENT '勝率',
  `acc_profit` float NOT NULL COMMENT '累積獲利',
  `acc_profit_margin` float NOT NULL COMMENT '累積獲利率',
  `enter_time` date NOT NULL COMMENT '進場時間',
  `exit_time` date NOT NULL COMMENT '出場時間',
  `continue_time` int(11) NOT NULL COMMENT '持續持間(天)',
  `buy_and_hold_return` float NOT NULL COMMENT '買入並持有報酬[%]',
  `html` text NOT NULL COMMENT '檔案名稱'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `test_head`
--

INSERT INTO `test_head` (`th_id`, `code_id`, `member_id`, `target_name`, `times`, `sucess_p`, `acc_profit`, `acc_profit_margin`, `enter_time`, `exit_time`, `continue_time`, `buy_and_hold_return`, `html`) VALUES
(1, 1, 0, '0056', 10, 60, 703.695, 7.03695, '2014-08-07', '2024-07-25', 3640, 56.3168, 'KDCross.html'),
(2, 1, 0, '0056', 10, 60, 703.695, 7.03695, '2014-08-07', '2024-07-25', 3640, 56.3168, 'KDCross.html');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `code`
--
ALTER TABLE `code`
  ADD PRIMARY KEY (`code_id`),
  ADD KEY `member_id` (`member_id`);

--
-- 資料表索引 `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`m_id`);

--
-- 資料表索引 `target`
--
ALTER TABLE `target`
  ADD PRIMARY KEY (`t_id`),
  ADD KEY `fk_target_member` (`member_id`);

--
-- 資料表索引 `test_body`
--
ALTER TABLE `test_body`
  ADD PRIMARY KEY (`tb_id`),
  ADD KEY `fk_test_body_head` (`th_id`);

--
-- 資料表索引 `test_head`
--
ALTER TABLE `test_head`
  ADD PRIMARY KEY (`th_id`),
  ADD KEY `fk_test_head_code` (`code_id`),
  ADD KEY `fk_test_head_member` (`member_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `code`
--
ALTER TABLE `code`
  MODIFY `code_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `members`
--
ALTER TABLE `members`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `target`
--
ALTER TABLE `target`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `test_body`
--
ALTER TABLE `test_body`
  MODIFY `tb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=771;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `test_head`
--
ALTER TABLE `test_head`
  MODIFY `th_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `code`
--
ALTER TABLE `code`
  ADD CONSTRAINT `fk_code_member` FOREIGN KEY (`member_id`) REFERENCES `members` (`m_id`);

--
-- 資料表的限制式 `target`
--
ALTER TABLE `target`
  ADD CONSTRAINT `fk_target_member` FOREIGN KEY (`member_id`) REFERENCES `members` (`m_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
