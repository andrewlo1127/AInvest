import sys
import random
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QSlider, QVBoxLayout, QMessageBox
from PyQt5.QtGui import QPixmap, QPainter, QBrush, QColor, QImage
from PyQt5.QtCore import Qt, QRect, QTimer

class SlidingPuzzleCaptcha(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        # 设置窗口标题和大小
        self.setWindowTitle('滑动拼图验证码')
        self.setFixedSize(400, 300)
        
        # 加载背景图片
        self.bg_image = QImage('test.jpg')
        self.block_size = 50
        
        # 随机生成缺口位置
        self.block_x = random.randint(0, self.bg_image.width() - self.block_size)
        self.block_y = random.randint(0, self.bg_image.height() - self.block_size)
        
        # 创建带缺口的背景图片
        self.image_with_hole = self.create_image_with_hole()
        
        # 创建标签来显示带缺口的图片
        self.image_label = QLabel(self)
        self.image_label.setPixmap(QPixmap.fromImage(self.image_with_hole))
        self.image_label.setFixedSize(self.bg_image.width(), self.bg_image.height())
        
        # 创建滑块
        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.setRange(0, self.bg_image.width() - self.block_size)
        self.slider.setTickPosition(QSlider.NoTicks)
        self.slider.setSingleStep(1)
        self.slider.valueChanged.connect(self.update_slider_position)
        self.slider.sliderReleased.connect(self.check_position)  # 滑块释放后检查位置
        
        # 创建滑块块
        self.slider_block = QLabel(self)
        self.slider_block.setFixedSize(self.block_size, self.block_size)
        self.slider_block.setPixmap(QPixmap.fromImage(self.create_slider_block_image()))
        
        # 布局
        layout = QVBoxLayout(self)
        layout.addWidget(self.image_label)
        layout.addWidget(self.slider)
        self.setLayout(layout)

        # 触发一次滑块位置更新
        QTimer.singleShot(100, lambda: self.update_slider_position(self.slider.value()))
    
    def create_image_with_hole(self):
        image = self.bg_image.copy()
        painter = QPainter(image)
        
        # 创建白色矩形来表示缺口
        painter.setBrush(QBrush(Qt.white))
        painter.setPen(Qt.NoPen)
        painter.drawRect(self.block_x, self.block_y, self.block_size, self.block_size)
        painter.end()
        
        return image

    def create_slider_block_image(self):
        # 从原图中切出块状图像
        block_image = self.bg_image.copy(QRect(self.block_x, self.block_y, self.block_size, self.block_size))
        return block_image

    def update_slider_position(self, value):
        # 更新滑块位置，并确保Y轴对齐
        self.slider_block.move(value + self.image_label.x(), self.block_y + self.image_label.y())
    
    def check_position(self):
        # 检查滑块位置是否对齐
        slider_x = self.slider_block.x() - self.image_label.x()
        if abs(slider_x - self.block_x) < 5:  # 允许一定的误差
            QMessageBox.information(self, '验证成功', '拼图对齐成功！')
            self.slider.setDisabled(True)
        else:
            QMessageBox.warning(self, '验证失败', '拼图对齐失败，请重试！')
            self.slider.setValue(0)  # 如果失败，将滑块重置到初始位置

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = SlidingPuzzleCaptcha()
    ex.show()
    sys.exit(app.exec_())
