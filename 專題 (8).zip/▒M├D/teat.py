import sys
import mysql.connector
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5 import uic, QtCore, QtGui
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
import resources_rc
from test1 import HtmlViewer, KDCross, calculate_kd, find_code_id, insert_rslt_to_db, find_th_id, insert_trades_to_db
import yfinance as yf
import hashlib, os

QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)
QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps)

class FetchStock:#观察清单数据获取
    def __init__(self, favorite_symbols):
        self.favorite_symbols = favorite_symbols

    def fetch_stock_data(self, symbol):
        market_codes = [".TW", ".TWO"]
        for market_code in market_codes:
            full_symbol = f"{symbol}{market_code}"
            stock = yf.Ticker(full_symbol)
            data = stock.history(period="5d")
            if not data.empty:
                close_price = data['Close'][-1]
                high_price = data['High'][-1]
                low_price = data['Low'][-1]
                open_price = data['Open'][-1]
                prev_close_price = data['Close'][-2] if len(data) > 1 else open_price
                price_change = close_price - prev_close_price
                price_change_percent = (price_change / prev_close_price) * 100
                return {
                    "symbol": symbol,
                    "market_code": market_code,
                    "open_price": f"{open_price:.2f}",
                    "close_price": f"{close_price:.2f}",
                    "high_price": f"{high_price:.2f}",
                    "low_price": f"{low_price:.2f}",
                    "prev_close_price": f"{prev_close_price:.2f}",
                    "price_change": f"{price_change:.2f}",
                    "price_change_percent": f"{price_change_percent:.2f}",
                    "is_favorite": symbol in self.favorite_symbols
                }
        return {"symbol": symbol, "error": "No data found"}

class LoginWindow(QWidget):#登录画面
    def __init__(self):
        super().__init__()
        self.db_connection = self.connect_to_db()
        self.initUI()

    def connect_to_db(self):
        try:
            connection = mysql.connector.connect(
                host='localhost',
                user='root',
                password='',
                database='專題'
            )
            return connection
        except mysql.connector.Error as err:
            QMessageBox.critical(None, "Database Connection Error", f"Error: {err}")
            sys.exit()

    def initUI(self):
        uic.loadUi("./login.ui", self)
        self.set_background()
        self.apply_fade_in_effect()
        self.login_button.clicked.connect(self.handle_login)
        self.quick_register.clicked.connect(self.show_register)
        self.forget_password.clicked.connect(self.handle_forget_password)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setIcon(QIcon('view.png'))
        self.toggle_button.setFixedSize(20, 20)
        self.toggle_button.setStyleSheet("QPushButton { border: none; }")
        self.toggle_button.clicked.connect(self.toggle_password_visibility)

    def toggle_password_visibility(self):
        if self.toggle_button.isChecked():
            self.password.setEchoMode(QLineEdit.Normal)
            self.toggle_button.setIcon(QIcon('view.png'))
        else:
            self.password.setEchoMode(QLineEdit.Password)
            self.toggle_button.setIcon(QIcon('hide.png'))

    def set_background(self):
        self.background_label = QLabel(self)
        self.background_label.setGeometry(0, 0, self.width(), self.height())
        self.background_label.setStyleSheet("background-image: url(:/invest_2.webp); background-repeat: no-repeat; background-position: center; background-size: cover;")
        self.background_label.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        self.background_label.lower()
        self.background_label.show()

    def resizeEvent(self, event):
        self.background_label.setGeometry(0, 0, self.width(), self.height())

    def apply_fade_in_effect(self):
        self.animations = []
        for child in self.findChildren(QWidget):
            if child == self.background_label:
                continue
            opacity_effect = QGraphicsOpacityEffect()
            child.setGraphicsEffect(opacity_effect)
            child.show()
            fade_in_animation = QPropertyAnimation(opacity_effect, b"opacity")
            fade_in_animation.setDuration(2000)
            fade_in_animation.setStartValue(0)
            fade_in_animation.setEndValue(1)
            fade_in_animation.finished.connect(lambda: self.cleanup_animation(opacity_effect))
            fade_in_animation.start()
            self.animations.append(fade_in_animation)

    def cleanup_animation(self, effect):
        effect.setOpacity(1)

    def handle_login(self):
        username = self.username.text()
        password = self.password.text()

        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        cursor = self.db_connection.cursor()
        query = "SELECT * FROM members WHERE name = %s AND password = %s"
        cursor.execute(query, (username, hashed_password))
        result = cursor.fetchone()
        cursor.close()
        if result:
            QMessageBox.information(None, "Login Success", "成功登錄")
            self.load_interface_ui(username)
        else:
            QMessageBox.warning(None, "Login Failed", "用戶名或者密碼錯誤")
    def show_register(self):
        self.register_window = RegisterWindow(self.db_connection)
        self.register_window.show()
        self.close()

    def load_interface_ui(self, username):
        self.interface_ui = IterfaceWindowLogined(username, self.db_connection)
        self.interface_ui.show()
        self.close()

    def handle_forget_password(self):
        QMessageBox.information(None, "Forget Password", "Forget password functionality is not implemented yet.")

class RegisterWindow(QWidget):#注册画面
    def __init__(self, db_connection):
        super().__init__()
        self.db_connection = db_connection
        self.initUI()

    def initUI(self):
        uic.loadUi("./register.ui", self)
        self.register_button.clicked.connect(self.handle_register)

    def handle_register(self):
        username = self.username.text()
        email = self.email.text()
        password = self.password.text()
        confirm_password = self.confirm_password.text()

        if confirm_password != password:
            QMessageBox.warning(None, "Registration Failed", "密碼不一致，請重新輸入")
            return

        cursor = self.db_connection.cursor()
        check_query = "SELECT * FROM members WHERE name = %s"
        cursor.execute(check_query, (username,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            QMessageBox.warning(None, "Registration Failed", "已經有人取過這個名字了")
        else:
            hashed_password = hashlib.sha256(password.encode()).hexdigest()
            query = "INSERT INTO members (name, email, password) VALUES (%s, %s, %s)"
            try:
                cursor = self.db_connection.cursor()
                cursor.execute(query, (username, email, hashed_password))
                self.db_connection.commit()
                cursor.close()
                QMessageBox.information(None, "Registration Success", "成功註冊!")
                self.show_interface()
            except mysql.connector.Error as err:
                QMessageBox.warning(None, "Registration Failed", f"Error: {err}")
                cursor.close()
    def show_interface(self):
        self.interface_window = IterfaceWindow()
        self.interface_window.show()
        self.close()

class IterfaceWindow(QWidget):#登录前的画面
    def __init__(self):
        super().__init__()
        self.db_connection = self.connect_to_db()
        self.initUI()
        self.fade_out_animation_connected = False

    def connect_to_db(self):
        try:
            connection = mysql.connector.connect(
                host='localhost',
                user='root',
                password='',
                database='專題'
            )
            return connection
        except mysql.connector.Error as err:
            QMessageBox.critical(None, "Database Connection Error", f"Error: {err}")
            sys.exit()

    def initUI(self):
        uic.loadUi("./interface.ui", self)
        self.layout = QVBoxLayout(self)
        self.hbox_layout = QHBoxLayout()
        self.layout.insertSpacerItem(0, QSpacerItem(0, 12, QSizePolicy.Minimum, QSizePolicy.Fixed))
        self.hbox_layout.addSpacerItem(QSpacerItem(-750, 0, QSizePolicy.Fixed, QSizePolicy.Minimum))
        self.table_widget = QTableWidget(self)
        self.table_widget.setRowCount(10)
        self.table_widget.setColumnCount(9)
        self.table_widget.setHorizontalHeaderItem(1, QTableWidgetItem('股票代號'))
        self.table_widget.setHorizontalHeaderItem(2, QTableWidgetItem('最新價'))
        self.table_widget.setHorizontalHeaderItem(3, QTableWidgetItem('漲跌'))
        self.table_widget.setHorizontalHeaderItem(4, QTableWidgetItem('漲跌%'))
        self.icon_add = QIcon('./add.png')
        header_item = QTableWidgetItem()
        header_item.setIcon(self.icon_add)
        header_item.setText("   ")
        header_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table_widget.setHorizontalHeaderItem(0, header_item)
        data = []
        for row, row_data in enumerate(data):
            for column, cell_data in enumerate(row_data):
                item = QTableWidgetItem(cell_data)
                self.table_widget.setItem(row, column + 1, item)
        self.icon1 = QIcon('./delete.png')
        for row in range(self.table_widget.rowCount()):
            if self.table_widget.item(row, 1):
                item_with_icon = QTableWidgetItem()
                item_with_icon.setIcon(self.icon1)
                item_with_icon.setText("")
                self.table_widget.setItem(row, 0, item_with_icon)
        self.table_widget.cellClicked.connect(self.on_cell_clicked)
        self.table_widget.horizontalHeader().sectionClicked.connect(self.on_header_clicked)
        self.table_widget.verticalHeader().setVisible(False)
        self.table_widget.setVisible(False)
        self.table_widget.setFixedSize(500, 400)
        self.table_widget.setColumnWidth(0, 10)
        self.table_widget.setColumnWidth(1, 60)
        self.table_widget.setColumnWidth(2, 60)
        self.table_widget.setColumnWidth(3, 50)
        self.table_widget.setColumnWidth(4, 50)
        self.table_widget.setStyleSheet("""
            QTableWidget {
                background-color: #3C3C3C;
                color: lightgray;
            }
            QTableWidget::item {
                background-color: #3C3C3C;
                color: lightgray;
            }
            QTableWidget::item:selected {
                background-color: #3C3C3C;
            }
            QScrollBar:vertical, QScrollBar:horizontal {
                background: #2e2e2e;
                width: 6px;
                height: 6px;
            }
            QHeaderView::section {
                background-color: #3C3C3C;
                color: white;
                border: 0px;
            }
            QScrollBar::handle:vertical, QScrollBar::handle:horizontal {
                background: #a0a0a0;
                border-radius: 2px;
                min-height: 20px;
                min-width: 20px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                background: none;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical,
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
                background: none;
            }
        """)
        self.opacity_effect = QGraphicsOpacityEffect(self.table_widget)
        self.table_widget.setGraphicsEffect(self.opacity_effect)
        self.fade_in_animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_in_animation.setDuration(200)
        self.fade_out_animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_out_animation.setDuration(200)
        self.hbox_layout.addWidget(self.table_widget)
        self.layout.addLayout(self.hbox_layout)
        self.table_widget.setShowGrid(False)
        self.pushButton_4.clicked.connect(self.show_login)
        self.pushButton_5.installEventFilter(self)
        self.pushButton_6.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(0))
        self.pushButton_7.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        self.table_widget.installEventFilter(self)

    def on_cell_clicked(self, row, column):
        if column == 0:
            self.delete_row(row)

    def delete_row(self, row):
        self.table_widget.cellClicked.disconnect(self.on_cell_clicked)
        stock_symbol = self.table_widget.item(row, 1).text()
        self.remove_stock_from_db(stock_symbol)
        self.table_widget.removeRow(row)
        if self.table_widget.rowCount() > 0:
            self.table_widget.removeRow(self.table_widget.rowCount() - 1)
        self.table_widget.cellClicked.connect(self.on_cell_clicked)

    def remove_stock_from_db(self, stock_symbol):
        cursor = self.db_connection.cursor()
        member_id = self.get_member_id()
        query = "DELETE FROM target WHERE target_id = %s AND member_id = %s"
        try:
            cursor.execute(query, (stock_symbol, member_id))
            self.db_connection.commit()
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error: {err}")
        cursor.close()

    def on_header_clicked(self, logicalIndex):
        if logicalIndex == 0:
            text, ok = QInputDialog.getText(self, 'Input Dialog', '請輸入股票代號:')
            if ok:
                fetch_stock = FetchStock(self.get_favorite_symbols())
                stock_data = fetch_stock.fetch_stock_data(text)
                if "error" in stock_data:
                    QMessageBox.warning(self, "Error", f"Error fetching data for {text}")
                else:
                    if not self.is_stock_already_added(stock_data['symbol']):
                        self.update_table_with_stock_data(stock_data)
                        self.save_stock_data_to_db(stock_data)
                    else:
                        QMessageBox.warning(self, "Error", "這個股票代號已經在觀察清單中。")

    def get_favorite_symbols(self):
        return ["2603", "4303"]

    def is_stock_already_added(self, stock_symbol):
        cursor = self.db_connection.cursor()
        member_id = self.get_member_id()
        query = "SELECT * FROM target WHERE target_id = %s AND member_id = %s"
        cursor.execute(query, (stock_symbol, member_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    def update_table_with_stock_data(self, stock_data):
        row_position = self.table_widget.rowCount()
        self.table_widget.insertRow(row_position)
        self.table_widget.setItem(row_position, 1, QTableWidgetItem(stock_data['symbol']))
        self.table_widget.setItem(row_position, 2, QTableWidgetItem(str(stock_data['close_price'])))
        self.table_widget.setItem(row_position, 3, QTableWidgetItem(str(stock_data['price_change'])))
        self.table_widget.setItem(row_position, 4, QTableWidgetItem(str(stock_data['price_change_percent'])))
        item_with_icon = QTableWidgetItem()
        item_with_icon.setIcon(self.icon1)
        item_with_icon.setText("")
        self.table_widget.setItem(row_position, 0, item_with_icon)

    def save_stock_data_to_db(self, stock_data):
        cursor = self.db_connection.cursor()
        member_id = self.get_member_id()
        query = "INSERT INTO target (target_id, member_id) VALUES (%s, %s)"
        try:
            cursor.execute(query, (stock_data['symbol'], member_id))
            self.db_connection.commit()
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error: {err}")
        cursor.close()

    def get_member_id(self):
        cursor = self.db_connection.cursor()
        username = self.findChild(QLineEdit, 'lineEdit').text()
        query = "SELECT m_id FROM members WHERE name = %s"
        cursor.execute(query, (username,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            return result[0]
        return None

    def eventFilter(self, obj, event):
        if obj == self.pushButton_5 or obj == self.table_widget:
            if event.type() == QtCore.QEvent.Enter:
                if self.fade_out_animation_connected:
                    self.fade_out_animation.finished.disconnect(self.hide_table)
                    self.fade_out_animation_connected = False
                self.show_table_with_animation()
            elif event.type() == QtCore.QEvent.Leave:
                self.hide_table_with_animation()
        return super().eventFilter(obj, event)

    def show_table_with_animation(self):
        self.table_widget.setVisible(True)
        self.fade_in_animation.setStartValue(0)
        self.fade_in_animation.setEndValue(1)
        self.fade_in_animation.start()

    def hide_table_with_animation(self):
        self.fade_out_animation.setStartValue(1)
        self.fade_out_animation.setEndValue(0)
        self.fade_out_animation.start()
        self.fade_out_animation.finished.connect(self.hide_table)
        self.fade_out_animation_connected = True

    def hide_table(self):
        self.table_widget.setVisible(False)

    def show_login(self):
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()

class IterfaceWindowLogined(QWidget):#登录后画面
    def __init__(self, username, db_connection):
        super().__init__()
        self.db_connection = db_connection
        self.username = username
        self.data = []
        self.initUI()
        self.fade_out_animation_connected = False
        self.load_stock_data()
        self.start_timer()
        self.load_trades_data()
        self.overlay = None

    def initUI(self):#一些界面UI,UX设定基本不动
        uic.loadUi("./interface_logined.ui", self)
        screen = QApplication.primaryScreen()
        dpi = screen.logicalDotsPerInch()
        print(f"Screen DPI: {dpi}")
        scale_factor = int(dpi / 96)
        self.setFixedSize(960 * scale_factor, 500 * scale_factor)

        # 设置窗口无边框
        self.setWindowFlags(Qt.FramelessWindowHint)
        
        # 设置圆角效果
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        # 退出按钮
        self.pushButton_6.clicked.connect(self.close)
        self.pushButton_7.setToolTip("主頁")
        self.pushButton_3.setToolTip("我的策略")
        self.pushButton_5.setToolTip("觀察清單")
        self.lineEdit.setReadOnly(True)
        self.lineEdit.setText(self.username)
        
        page_2 = self.stackedWidget.widget(1)
        page_2_layout = QVBoxLayout(page_2)
        splitter = QSplitter(Qt.Vertical)
        splitter.setStyleSheet("QSplitter::handle { background-color: transparent; }")
        self.viewer = HtmlViewer()
        splitter.addWidget(self.viewer)
        self.tabWidget = QTabWidget()
        tab1 = QWidget()
        tab1_layout = QVBoxLayout(tab1)
        tab1_layout.addWidget(self.widget_edit_st)
        self.tabWidget.addTab(tab1, "策略參數調整")
        tab2 = QWidget()
        tab2_layout = QVBoxLayout(tab2)
        tab2_layout.addWidget(self.tableWidget)
        self.tabWidget.addTab(tab2, "交易明細")
        splitter.addWidget(self.tabWidget)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)
        page_2_layout.addWidget(splitter)
        page_2.setLayout(page_2_layout)
        self.pushButton_7.clicked.connect(self.go_to_page_2)
        self.pushButton_3.clicked.connect(self.go_to_page_3)
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(5)
        self.table_widget.setHorizontalHeaderItem(1, QTableWidgetItem('股票代號'))
        self.table_widget.setHorizontalHeaderItem(2, QTableWidgetItem('最新價'))
        self.table_widget.setHorizontalHeaderItem(3, QTableWidgetItem('漲跌'))
        self.table_widget.setHorizontalHeaderItem(4, QTableWidgetItem('漲跌%'))
        self.icon_add = QIcon('./add.png')
        header_item = QTableWidgetItem()
        header_item.setIcon(self.icon_add)
        header_item.setText("   ")
        header_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table_widget.setHorizontalHeaderItem(0, header_item)
        self.icon1 = QIcon('./delete.png')
        for row in range(self.table_widget.rowCount()):
            if self.table_widget.item(row, 1):
                item_with_icon = QTableWidgetItem()
                item_with_icon.setIcon(self.icon1)
                item_with_icon.setText("")
                self.table_widget.setItem(row, 0, item_with_icon)
        self.table_widget.cellClicked.connect(self.on_cell_clicked)
        self.table_widget.horizontalHeader().sectionClicked.connect(self.on_header_clicked)
        self.table_widget.verticalHeader().setVisible(False)
        self.table_widget.setVisible(False)
        self.table_widget.setFixedSize(250, 350)
        self.tableWidget.setColumnWidth(0, 130)
        self.tableWidget.setColumnWidth(1, 130)
        self.table_widget.setColumnWidth(0, 10)
        self.table_widget.setColumnWidth(1, 60)
        self.table_widget.setColumnWidth(2, 60)
        self.table_widget.setColumnWidth(3, 50)
        self.table_widget.setColumnWidth(4, 50)
        self.tableWidget_mylist.setColumnWidth(0, 150)
        self.tableWidget_mylist.setColumnWidth(1, 300)
        self.tableWidget_mylist.setColumnWidth(2, 100)
        self.pushButton_8.clicked.connect(self.on_header_clicked_mylist)
        self.fill_example_data()
        for row in range(self.tableWidget_mylist.rowCount()):
            if self.tableWidget_mylist.item(row, 1):
                self.add_button_to_table(row, 2)

        self.table_widget.setShowGrid(False)

        self.pushButton_5.clicked.connect(self.toggle_table_widget_visibility)
        self.pushButton_4.clicked.connect(self.show_member_info)

        self.member_info_app = MemberInfoDialog(self.db_connection, self.get_member_id())
        self.stackedWidget.insertWidget(0, self.member_info_app)
        self.load_trades_data()

        # 获取UI中的控件
        self.bot_icon = self.findChild(QPushButton, "bot_icon")
        self.text_chat = self.findChild(QTextEdit, "text_chat")

        # 初始化聊天窗口为隐藏状态
        self.text_chat.hide()

        # 连接按钮点击事件到方法
        self.bot_icon.clicked.connect(self.toggle_chat_window)

    def paintEvent(self, event):#圆角动画
        path = QPainter(self)
        path.setRenderHint(QPainter.Antialiasing)
        path.setBrush(QBrush(QColor(255, 255, 255)))
        path.setPen(Qt.NoPen)
        path.drawRoundedRect(self.rect(), 15, 15)
    def load_public_list(self): #加载公共策略画面
        cursor = self.db_connection.cursor()
        query = "SELECT strategy, description FROM code WHERE public = 1"
        cursor.execute(query)
        public_strategies = cursor.fetchall()
        cursor.close()

        self.tableWidget_mylist_2.setRowCount(len(public_strategies))
        self.tableWidget_mylist_2.setColumnCount(3)
        self.tableWidget_mylist_2.setColumnWidth(0, 150)
        self.tableWidget_mylist_2.setColumnWidth(1, 300)
        self.tableWidget_mylist_2.setColumnWidth(2, 100)

        for row_index, row_data in enumerate(public_strategies):
            for col_index, cell_data in enumerate(row_data):
                self.tableWidget_mylist_2.setItem(row_index, col_index, QTableWidgetItem(cell_data))

            self.button_increase = QPushButton("新增")
            self.button_increase.clicked.connect(lambda: self.add_strategy(row_index))
            self.tableWidget_mylist_2.setCellWidget(row_index, 2, self.button_increase)
        self.button_increase.setStyleSheet("""
            QPushButton {
                background-color: lightgray; 
                color: black;
                border: none;
                padding: 5px 10px;
                
            }
            QPushButton:hover {
                background-color: skyblue;
                color: white;
            }
            """)
        self.stackedWidget.setCurrentIndex(4)

    def add_strategy(self, row_index):#
        strategy = self.tableWidget_mylist_2.item(row_index, 0).text()
        description = self.tableWidget_mylist_2.item(row_index, 1).text()
        # 在这里添加处理增加策略的逻辑
        print(f"增加策略: {strategy}, 描述: {description}")

    def fill_example_data(self): #填充公共策略 连上sql这个可以删
        example_data = [
            ["001", "股票 A"],
            ["002", "股票 B"],
            ["003", "股票 C"]
        ]
        self.tableWidget_mylist.setRowCount(len(example_data))
        self.tableWidget_mylist.setColumnCount(3)
        for row_index, row_data in enumerate(example_data):
            for col_index, cell_data in enumerate(row_data):
                self.tableWidget_mylist.setItem(row_index, col_index, QTableWidgetItem(cell_data))
            self.add_button_to_table(row_index, 2)

    def add_button_to_table(self, row, column): #增加编辑按钮
        button = QPushButton("編輯")
        button.setStyleSheet("""
            QPushButton {
                background-color: lightgray; 
                color: black;
                border: none;
                padding: 5px 10px;
                
            }
            QPushButton:hover {
                background-color: skyblue;
                color: white;
            }
            """)
        button.clicked.connect(lambda: self.on_edit_button_clicked(row))
        container = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(button)
        layout.setContentsMargins(0, 0, 0, 0)
        container.setLayout(layout)
        self.tableWidget_mylist.setCellWidget(row, column, container)

    def on_edit_button_clicked(self, row):
        print(f"编辑按钮在行 {row} 被点击")
        self.show_edit() #show出edit画面

    def load_trades_data(self): #加载交易明细画面
        font = QFont()
        font.setFamily("Bahnschrift")
        import test1
        trades = test1.test1_main()
        self.tableWidget.setRowCount(len(trades))
        for row_index, row_data in enumerate(trades.itertuples(index=False)):
            formatted_data = [
                row_data.EntryTime,
                row_data.ExitTime,
                round(row_data.EntryPrice),
                round(row_data.ExitPrice),
                round(row_data.Size),
                round(row_data.PnL),
                f"{row_data.ReturnPct:.5f}"
            ]
            for col_index, cell_data in enumerate(formatted_data):
                item = QTableWidgetItem(str(cell_data))
                item.setFont(font)
                item.setTextAlignment(Qt.AlignCenter)
                self.tableWidget.setItem(row_index, col_index, item)
    def refresh_table_widget(self):
        self.table_widget.clearContents()
        self.table_widget.setRowCount(0)
        self.load_stock_data()


    def go_to_page_3(self):
        print("Switching to page 3")
        self.stackedWidget.setCurrentIndex(3)

    def toggle_table_widget_visibility(self):#table一开始的可见度
        if self.table_widget.isVisible():
            self.hide_table_with_animation()
        else:
            self.show_table_with_animation()

    def show_member_info(self):
        self.show_member()
    
    def on_cell_clicked(self, row, column):
        if column == 0:
            self.delete_row(row)
    
    def delete_row(self, row):
        self.table_widget.cellClicked.disconnect(self.on_cell_clicked)
        stock_symbol = self.table_widget.item(row, 1).text()
        self.remove_stock_from_db(stock_symbol)
        self.table_widget.removeRow(row)
        self.table_widget.cellClicked.connect(self.on_cell_clicked)

    def remove_stock_from_db(self, stock_symbol):
        cursor = self.db_connection.cursor()
        member_id = self.get_member_id()
        query = "DELETE FROM target WHERE target_id = %s AND member_id = %s"
        try:
            cursor.execute(query, (stock_symbol, member_id))
            self.db_connection.commit()
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error: {err}")
        cursor.close()

    def button_clicked_increase(self):
        print("轉移至新增策略")

    def on_header_clicked(self, logicalIndex):#不用管
        if logicalIndex == 0:
            text, ok = QInputDialog.getText(self, 'Input Dialog', '請輸入股票代號:')
            if ok:
                fetch_stock = FetchStock(self.get_favorite_symbols())
                stock_data = fetch_stock.fetch_stock_data(text)
                if "error" in stock_data:
                    QMessageBox.warning(self, "Error", f"Error fetching data for {text}")
                else:
                    if not self.is_stock_already_added(stock_data['symbol']):
                        self.update_table_with_stock_data(stock_data)
                        self.save_stock_data_to_db(stock_data)
                    else:
                        QMessageBox.warning(self, "Error", "這個股票代號已經在觀察清單中。")

    def on_header_clicked_mylist(self):#不用管
        self.load_public_list()

    def get_favorite_symbols(self):#不用管
        return ["2603", "4303"]

    def is_stock_already_added(self, stock_symbol):#不用管
        cursor = self.db_connection.cursor()
        member_id = self.get_member_id()
        query = "SELECT * FROM target WHERE target_id = %s AND member_id = %s"
        cursor.execute(query, (stock_symbol, member_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    def update_table_with_stock_data(self, stock_data):#不用管
        new_data = [
            stock_data['symbol'],
            stock_data['close_price'],
            stock_data['price_change'],
            stock_data['price_change_percent']
        ]
        self.data.append(new_data)
        row_position = self.table_widget.rowCount()
        self.table_widget.insertRow(row_position)
        for column, cell_data in enumerate(new_data):
            self.table_widget.setItem(row_position, column + 1, QTableWidgetItem(cell_data))
        item_with_icon = QTableWidgetItem()
        item_with_icon.setIcon(self.icon1)
        item_with_icon.setText("")
        self.table_widget.setItem(row_position, 0, item_with_icon)

    def save_stock_data_to_db(self, stock_data):#不用管
        cursor = self.db_connection.cursor()
        member_id = self.get_member_id()
        query = "INSERT INTO target (target_id, member_id) VALUES (%s, %s)"
        try:
            cursor.execute(query, (stock_data['symbol'], member_id))
            self.db_connection.commit()
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error: {err}")
        cursor.close()

    def get_member_id(self):#不用管
        cursor = self.db_connection.cursor()
        query = "SELECT m_id FROM members WHERE name = %s"
        cursor.execute(query, (self.username,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            return result[0]
        return None

    def load_stock_data(self):#不用管
        cursor = self.db_connection.cursor()
        member_id = self.get_member_id()
        query = "SELECT target_id FROM target WHERE member_id = %s"
        cursor.execute(query, (member_id,))
        stocks = cursor.fetchall()
        cursor.close()
        for stock in stocks:
            stock_symbol = stock[0]
            fetch_stock = FetchStock(self.get_favorite_symbols())
            stock_data = fetch_stock.fetch_stock_data(stock_symbol)
            if "error" not in stock_data:
                self.update_table_with_stock_data(stock_data)

    def start_timer(self):#不用管
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_stock_data)
        self.timer.start(5000)

    def refresh_stock_data(self):#不用管
        for i in range(self.table_widget.rowCount()):
            stock_symbol = self.table_widget.item(i, 1).text()
            fetch_stock = FetchStock(self.get_favorite_symbols())
            stock_data = fetch_stock.fetch_stock_data(stock_symbol)
            if "error" not in stock_data:
                self.table_widget.setItem(i, 2, QTableWidgetItem(stock_data['close_price']))
                self.table_widget.setItem(i, 3, QTableWidgetItem(stock_data['price_change']))
                self.table_widget.setItem(i, 4, QTableWidgetItem(stock_data['price_change_percent']))

    def show_table_with_animation(self):
        self.table_widget.setVisible(True)
    def hide_table_with_animation(self):
        self.table_widget.setVisible(False)
    def show_member(self):
        self.overlay = QWidget(self)
        self.overlay.setStyleSheet("background-color: rgba(0, 0, 0, 150);")
        self.overlay.setGeometry(self.rect())
        self.overlay.show()
        member_id = self.get_member_id()
        self.member_window = MemberInfoDialog(self.db_connection, member_id, self)
        self.member_window.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.member_window.setAttribute(Qt.WA_TranslucentBackground)
        self.member_window.setWindowModality(Qt.ApplicationModal)
        self.member_window.resize(484, 300)
        self.member_window.move(
            self.geometry().center() - self.member_window.rect().center()
        )

        self.opacity_effect = QGraphicsOpacityEffect(self.member_window)
        self.member_window.setGraphicsEffect(self.opacity_effect)

        self.fade_in_animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_in_animation.setDuration(500)
        self.fade_in_animation.setStartValue(0)
        self.fade_in_animation.setEndValue(1)
        self.fade_in_animation.start()

        self.member_window.show()


    def show_edit(self):
        self.overlay = QWidget(self)
        self.overlay.setStyleSheet("background-color: rgba(0, 0, 0, 150);")
        self.overlay.setGeometry(self.rect())
        self.overlay.show()

        self.edit_window = EditDialog(self)
        self.edit_window.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.edit_window.setAttribute(Qt.WA_TranslucentBackground)
        self.edit_window.setWindowModality(Qt.ApplicationModal)
        self.edit_window.resize(484, 300)
        self.edit_window.move(
            self.geometry().center() - self.edit_window.rect().center()
        )

        self.opacity_effect = QGraphicsOpacityEffect(self.edit_window)
        self.edit_window.setGraphicsEffect(self.opacity_effect)

        self.fade_in_animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_in_animation.setDuration(500)
        self.fade_in_animation.setStartValue(0)
        self.fade_in_animation.setEndValue(1)
        self.fade_in_animation.start()

        self.edit_window.show()
    def go_to_page_2(self):
        print("Switching to page 2")
        self.stackedWidget.setCurrentIndex(2)
class MemberInfoDialog(QDialog):#会员资讯画面
    def __init__(self, db_connection, member_id, parent=None):
        super().__init__(parent)
        self.db_connection = db_connection
        self.member_id = member_id
        uic.loadUi("member.ui", self)  # 加载 member.ui 文件
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.label_name = self.findChild(QLabel, "label_name")  # 查找 QLabel 控件用于显示姓名
        self.label_email = self.findChild(QLabel, "label_email")  # 查找 QLabel 控件用于显示电子邮件
        self.pushButton = self.findChild(QPushButton, "pushButton")  # 查找 QPushButton 控件用于更改密码
        self.pushButton_2 = self.findChild(QPushButton, "pushButton_2")  # 查找 QPushButton 控件用于关闭对话框

        self.load_member_info()  # 加载会员信息

        self.pushButton.clicked.connect(self.change_password)  # 绑定更改密码按钮的点击事件
        self.pushButton_2.clicked.connect(self.close)  # 绑定关闭按钮的点击事件

    def load_member_info(self):
        cursor = self.db_connection.cursor()
        query = "SELECT name, email FROM members WHERE m_id = %s"
        cursor.execute(query, (self.member_id,))
        member = cursor.fetchone()
        if member:
            name, email = member
            self.label_name.setText(name)  # 将姓名设置到 QLabel
            self.label_email.setText(email)  # 将电子邮件设置到 QLabel
        else:
            QMessageBox.warning(self, "警告", "没有找到会员资料")
        cursor.close()

    def change_password(self):
        self.change_password_window = ChangePasswordWindow(self.db_connection, self.member_id)
        self.change_password_window.exec_()

    def closeEvent(self, event):
        parent = self.parent()
        if parent and hasattr(parent, 'overlay') and parent.overlay:
            parent.overlay.close()
        super().closeEvent(event)

    def paintEvent(self, event):
        # 绘制圆角矩形背景
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        rect = QRectF(self.rect())
        radius = 15  # 调整这个值以改变圆角的半径
        path = QtGui.QPainterPath()
        path.addRoundedRect(rect, radius, radius)
        painter.fillPath(path, QtGui.QBrush(QtGui.QColor(255, 255, 255, 255)))
        painter.setPen(Qt.NoPen)
        painter.drawPath(path)
class EditDialog(QDialog):#编辑策略画面
    def __init__(self, parent=None):
        super().__init__(parent)
        # 加载 UI 文件
        uic.loadUi('edit_st.ui', self)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # 处理 pushButton_2 点击事件
        self.pushButton_2.clicked.connect(self.close)

    def closeEvent(self, event):#关闭
        parent = self.parent()
        if parent and hasattr(parent, 'overlay'):
            parent.overlay.close()
        super().closeEvent(event)

    def paintEvent(self, event):#圆角
        # 绘制圆角矩形背景
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        rect = QRectF(self.rect())
        radius = 15  # 调整这个值以改变圆角的半径
        path = QtGui.QPainterPath()
        path.addRoundedRect(rect, radius, radius)
        painter.fillPath(path, QtGui.QBrush(QtGui.QColor(255, 255, 255, 255)))
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawPath(path)

class ChangePasswordWindow(QDialog):#更改密码画面
    def __init__(self, db_connection, member_id, parent=None):
        super().__init__(parent)
        self.db_connection = db_connection
        self.member_id = member_id
        uic.loadUi('change_password.ui', self)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)

        self.initUI()

    def initUI(self):
        self.old_password = self.findChild(QLineEdit, "old_password")
        self.new_password = self.findChild(QLineEdit, "new_password")
        self.new_password_toggle = self.findChild(QPushButton, "new_password_toggle")
        self.confirm_password = self.findChild(QLineEdit, "confirm_password")
        self.submit_button = self.findChild(QPushButton, "submit_button")

        # 设置旧密码输入框为密码模式
        self.old_password.setEchoMode(QLineEdit.Password)

        # 设置新密码输入框为密码模式
        self.new_password.setEchoMode(QLineEdit.Password)

        # 连接显示/隐藏密码按钮的点击事件
        self.new_password_toggle.clicked.connect(self.toggle_password_visibility)

        # 连接变更密码按钮的点击事件
        self.submit_button.clicked.connect(self.change_password)
        self.pushButton_2.clicked.connect(self.close)

    def toggle_password_visibility(self):
        if self.new_password.echoMode() == QLineEdit.Password:
            self.new_password.setEchoMode(QLineEdit.Normal)
            self.new_password_toggle.setText("隱藏密碼")
        else:
            self.new_password.setEchoMode(QLineEdit.Password)
            self.new_password_toggle.setText("顯示密碼")

    def change_password(self):
        old_password = self.old_password.text()
        new_password = self.new_password.text()
        confirm_password = self.confirm_password.text()

        if new_password != confirm_password:
            QMessageBox.warning(self, "錯誤", "新密碼與確認密碼不一致")
            return

        hashed_old_password = hashlib.sha256(old_password.encode()).hexdigest()
        hashed_new_password = hashlib.sha256(new_password.encode()).hexdigest()

        cursor = self.db_connection.cursor()
        query = "SELECT password FROM members WHERE m_id = %s"
        cursor.execute(query, (self.member_id,))
        result = cursor.fetchone()
        if result and result[0] == hashed_old_password:
            update_query = "UPDATE members SET password = %s WHERE m_id = %s"
            cursor.execute(update_query, (hashed_new_password, self.member_id))
            self.db_connection.commit()
            QMessageBox.information(self, "成功", "密碼變更成功")
            self.close()
        else:
            QMessageBox.warning(self, "錯誤", "舊密碼不正確")
        cursor.close()

    def closeEvent(self, event):
        parent = self.parent()
        if parent and hasattr(parent, 'overlay'):
            parent.overlay.close()
        super().closeEvent(event)

    def paintEvent(self, event):
        # 绘制圆角矩形背景
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        rect = QRectF(self.rect())
        radius = 15  # 调整这个值以改变圆角的半径
        path = QtGui.QPainterPath()
        path.addRoundedRect(rect, radius, radius)
        painter.fillPath(path, QtGui.QBrush(QtGui.QColor(255, 255, 255, 255)))
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawPath(path)
if __name__ == '__main__':
    app = QApplication(sys.argv)
    interface_window = IterfaceWindow()
    interface_window.show()
    sys.exit(app.exec_())
