import pymysql
def find_tempt_code(strategy_name, connection):
    with connection.cursor() as cursor:
        sql = """
        SELECT tempt_code
        FROM code
        WHERE strategy = %s
        """
        cursor.execute(sql, (strategy_name,))
        code = cursor.fetchone()[0]
    return code

def test3_main(strategy_name):
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'aiinvest'
    }
    connection = pymysql.connect(**db_config)
    with(open('./strategy_backtest.py', 'w', encoding='utf-8')) as f:
        code = find_tempt_code(strategy_name, connection)
        for i in code:
            if i == '\n':
                f.write('')
            else:
                f.write(i)
    f.close()
    connection.close()

if __name__ == "__main__":
    test3_main()