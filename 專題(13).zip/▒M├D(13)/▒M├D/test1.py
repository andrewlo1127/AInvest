import yfinance as yf
from backtesting import Backtest, Strategy
from backtesting.lib import crossover
import pymysql
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl
import sys
import os

class HtmlViewer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.browser = QWebEngineView()
        self.setCentralWidget(self.browser)
        # 使用绝对路径
        file_path = os.path.abspath("./KDCross.html")
        url = QUrl.fromLocalFile(file_path)
        self.browser.setUrl(url)
        self.setWindowTitle("HTML Viewer")

# 定義策略
class KDCross(Strategy):
    lower_bound = 20
    upper_bound = 80

    def init(self):
        self.k = self.I(lambda: self.data['K'], name='K')
        self.d = self.I(lambda: self.data['D'], name='D')

    def next(self):
        if crossover(self.k, self.d) and self.k[-1] < self.lower_bound and self.d[-1] < self.lower_bound and not self.position:
            self.buy()
        elif crossover(self.d, self.k) and self.k[-1] > self.upper_bound and self.d[-1] > self.upper_bound:
            if self.position and self.position.is_long:
                self.position.close()

# 計算 KD 指標
def calculate_kd(df, period=9, signal_period=3):
    df = df.copy()
    high_max = df['High'].rolling(window=period).max()
    low_min = df['Low'].rolling(window=period).min()
    df['RSV'] = 100 * ((df['Close'] - low_min) / (high_max - low_min))
    df['K'] = df['RSV'].ewm(alpha=1/signal_period).mean()
    df['D'] = df['K'].ewm(alpha=1/signal_period).mean()
    return df

def find_code_id(rslt, connection):
    with connection.cursor() as cursor:
        sql = """
        SELECT code_id
        FROM code
        WHERE strategy = %s
        """
        cursor.execute(sql, (repr(rslt['_strategy']).replace('<Strategy ','').replace('>',''),))
        code_id = cursor.fetchone()[0]
    return code_id

# 將結果寫入資料庫
def insert_rslt_to_db(rslt, code_id, ticker, connection,member_id):
    with connection.cursor() as cursor:
        result_sql = """
        INSERT INTO test_head (code_id, member_id, target_name, times, sucess_p, acc_profit, acc_profit_margin, enter_time, exit_time, continue_time, buy_and_hold_return, html)
        VALUES (%s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(result_sql, (
            code_id,
            member_id,
            ticker.replace('.TW', ''),
            rslt['# Trades'],
            rslt['Win Rate [%]'],
            rslt['Return'],
            rslt['Return [%]'],
            rslt['Start'],
            rslt['End'],
            rslt['Duration'],
            rslt['Buy & Hold Return [%]'],
            repr(rslt['_strategy']).replace('<Strategy ','').replace('>','')+'.html'
        ))
        connection.commit()

def find_th_id(connection):
    with connection.cursor() as cursor:
        sql = """
        SELECT th_id
        FROM test_head
        ORDER BY th_id DESC
        LIMIT 1
        """
        cursor.execute(sql)
        th_id = cursor.fetchone()[0]
    return th_id

def insert_trades_to_db(trades, th_id, connection):
    with connection.cursor() as cursor:
        for index, trade in trades.iterrows():
            sql = """
            INSERT INTO test_body (th_id, enter_date, exit_date, enter_price, exit_price, size, profit, profit_margin)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (
                th_id,
                trade['EntryTime'],
                trade['ExitTime'],
                trade['EntryPrice'],
                trade['ExitPrice'],
                trade['Size'],
                trade['PnL'],
                trade['ReturnPct']
            ))
        connection.commit()

def test1_main(data,member_id):
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': '專題'
    }
    connection = pymysql.connect(**db_config)

    # 下載股票歷史數據
    ticker = data[0]
    start_date = data[2]
    end_date = data[3]
    df = yf.download(ticker, start=start_date, end=end_date)

    # 計算 KD
    df = calculate_kd(df)

    # 運行回測
    bt = Backtest(df.dropna(), KDCross, cash=10000, commission=.002)
    rslt = bt.run()
    print(rslt)
    print("\n", rslt["_trades"])

    rslt["Return"] = 0
    for index, trade in rslt['_trades'].iterrows():
        rslt["Return"] += float(trade['PnL'])
    html_file = f"KDCross.html"
    bt.plot(filename=html_file, open_browser=False)

    code_id = find_code_id(rslt, connection)
    insert_rslt_to_db(rslt, code_id, ticker, connection,member_id)
    th_id = find_th_id(connection)
    insert_trades_to_db(rslt['_trades'], th_id, connection)

    connection.close()
    print(data[0])
    # 返回只包含所需字段的 DataFrame
    return rslt['_trades'][['EntryTime', 'ExitTime', 'EntryPrice', 'ExitPrice', 'Size', 'PnL', 'ReturnPct']]



if __name__ == '__main__':
    test1_main()
