from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QLabel, QGraphicsBlurEffect, QWidget
from PyQt5.QtGui import QColor, QPainter
from PyQt5.QtCore import Qt
import sys

class FrostedGlassWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setAttribute(Qt.WA_TranslucentBackground)  # 透明背景

        # 设置布局
        layout = QVBoxLayout()
        self.setLayout(layout)

        # 创建一个标签用于显示模糊效果
        label = QLabel("雾面玻璃效果")
        label.setStyleSheet("color: white; font-size: 24px;")
        layout.addWidget(label)


    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # 设置半透明背景颜色
        color = QColor(255, 255, 255, 120)  # RGBA (白色，透明度50%)
        painter.setBrush(color)
        painter.setPen(Qt.NoPen)

        # 绘制矩形背景
        painter.drawRoundedRect(self.rect(), 10, 10)

class TransparentMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowFlags(Qt.FramelessWindowHint)  # 无边框窗口
        self.setAutoFillBackground(True)

        # 创建一个主窗口小部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 创建布局
        layout = QVBoxLayout(central_widget)

        # 添加雾面玻璃效果小部件
        frosted_glass = FrostedGlassWidget()
        layout.addWidget(frosted_glass)
        

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = TransparentMainWindow()
    main_window.setWindowTitle('Transparent Window with Frosted Glass Effect')

    main_window.resize(400, 300)
    main_window.show()

    sys.exit(app.exec_())
