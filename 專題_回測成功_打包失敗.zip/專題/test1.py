import importlib
import yfinance as yf
from backtesting import Backtest, Strategy
from backtesting.lib import crossover
import pymysql
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl
import sys
import os
import py_compile

class HtmlViewer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.browser = QWebEngineView()
        self.setCentralWidget(self.browser)
        # 使用绝对路径
        file_path = os.path.abspath("./Strategy.html")
        url = QUrl.fromLocalFile(file_path)
        self.browser.setUrl(url)
        self.setWindowTitle("HTML Viewer")

def find_code_id(name, rslt, connection):
    with connection.cursor() as cursor:
        sql = """
        SELECT code_id
        FROM code
        WHERE strategy = %s
        """
        cursor.execute(sql, (name,))
        code_id = cursor.fetchone()[0]
    return code_id

# 將結果寫入資料庫
def insert_rslt_to_db(name, rslt, code_id, ticker, connection,member_id):
    with connection.cursor() as cursor:
        result_sql = """
        INSERT INTO test_head (code_id, member_id, target_name, times, sucess_p, acc_profit, acc_profit_margin, enter_time, exit_time, continue_time, buy_and_hold_return, html)
        VALUES (%s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(result_sql, (
            code_id,
            member_id,
            ticker.replace('.TW', ''),
            rslt['# Trades'],
            rslt['Win Rate [%]'],
            rslt['Return'],
            rslt['Return [%]'],
            rslt['Start'],
            rslt['End'],
            rslt['Duration'],
            rslt['Buy & Hold Return [%]'],
            name+'.html'
        ))
        connection.commit()

def find_th_id(connection):
    with connection.cursor() as cursor:
        sql = """
        SELECT th_id
        FROM test_head
        ORDER BY th_id DESC
        LIMIT 1
        """
        cursor.execute(sql)
        th_id = cursor.fetchone()[0]
    return th_id

def insert_trades_to_db(trades, th_id, connection):
    with connection.cursor() as cursor:
        for index, trade in trades.iterrows():
            sql = """
            INSERT INTO test_body (th_id, enter_date, exit_date, enter_price, exit_price, size, profit, profit_margin)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (
                th_id,
                trade['EntryTime'],
                trade['ExitTime'],
                trade['EntryPrice'],
                trade['ExitPrice'],
                trade['Size'],
                trade['PnL'],
                trade['ReturnPct']
            ))
        connection.commit()

def test1_main(data,member_id):
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'aiinvest'
    }
    connection = pymysql.connect(**db_config)

    # 下載股票歷史數據
    ticker = data[0]
    start_date = data[2]
    end_date = data[3]
    df = yf.download(ticker, start=start_date, end=end_date)

    # with open("strategy_backtest.py", "r", encoding="utf-8") as file:
    #     content = file.read()
    #     print(content)  # 應該顯示新的內容
    #     file.close()

    # 刪除 .pyc 文件
    pyc_file = "./__pycache__/strategy_backtest.cpython-37.pyc"
    if os.path.exists(pyc_file):
        os.remove(pyc_file)
        print(f"已刪除: {pyc_file}")
    else:
        print(f"文件不存在: {pyc_file}")

    # # 指定要编译的 Python 文件
    # python_file = './strategy_backtest.py'
    # # 生成 .pyc 文件
    # py_compile.compile(python_file, cfile='./__pycache__/strategy_backtest.cpython-37.pyc', dfile=None, optimize=-1)
    # print(f"已生成: ./__pycache__/strategy_backtest.cpython-37.pyc")

    # 确保模块路径正确
    module_name = 'strategy_backtest'
    module_file_path = './strategy_backtest.py'

    # 删除旧的模块
    if module_name in sys.modules:
        del sys.modules[module_name]
        print(f"刪掉 {module_name} 模組")

    # 动态执行最新的文件内容
    with open(module_file_path, "r", encoding="utf-8") as file:
        script_content = file.read()
        exec(script_content, globals())
        file.close()

    # 确保模块被正确导入和重新加载
    import strategy_backtest
    importlib.reload(strategy_backtest)

    # 計算 KD
    df = strategy_backtest.calculate(df)

    # 抓取策略名稱
    name = strategy_backtest.name()  # 調用實例的 name() 方法
    print("name:", name)

    # 運行回測
    bt = Backtest(df.dropna(), strategy_backtest.strategy, cash=10000, commission=.002)
    rslt = bt.run()
    print(rslt)
    print("\n", rslt["_trades"])

    rslt["Return"] = 0
    for index, trade in rslt['_trades'].iterrows():
        rslt["Return"] += float(trade['PnL'])
    # html_file = f"Strategy.html"
    # bt.plot(filename=html_file, open_browser=False)
    bt.plot(open_browser=False)

    code_id = find_code_id(name, rslt, connection)
    insert_rslt_to_db(name, rslt, code_id, ticker, connection,member_id)
    th_id = find_th_id(connection)
    insert_trades_to_db(rslt['_trades'], th_id, connection)

    connection.close()
    print(data[0])
    # 返回只包含所需字段的 DataFrame
    return rslt['_trades'][['EntryTime', 'ExitTime', 'EntryPrice', 'ExitPrice', 'Size', 'PnL', 'ReturnPct']]

if __name__ == '__main__':
    test1_main()